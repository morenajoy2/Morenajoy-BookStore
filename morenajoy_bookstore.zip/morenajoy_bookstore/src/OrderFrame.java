
import java.awt.Toolkit;
import java.awt.event.ItemEvent;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;
import javax.swing.*;
import javax.swing.JOptionPane;

//Database
import java.sql.Connection;
import java.sql.PreparedStatement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Nicole Joy Hernandez
 */
public class OrderFrame extends javax.swing.JFrame {

    /**
     * Creates new form HERNANDEZ_SA1
     */
    private boolean carton = false, bubble = false, book = false;

    public OrderFrame() {
        initComponents();

        setIconImage();

        ButtonGroup courierGroup = new ButtonGroup();
        courierGroup.add(rbShop);
        courierGroup.add(rbJt);
        courierGroup.add(rbLbc);
        courierGroup.add(rbJres);
        courierGroup.add(rbLamove);
        courierGroup.add(rb2go);

        ButtonGroup paymentGroup = new ButtonGroup();
        paymentGroup.add(rbGcash);
        paymentGroup.add(rbPaymaya);
        paymentGroup.add(rbMetrobank);
        paymentGroup.add(rbBdo);
        paymentGroup.add(rbCod);

        ButtonGroup bookTypeGroup = new ButtonGroup();
        bookTypeGroup.add(rbBa);
        bookTypeGroup.add(rbTlc);
    }

    private String getSelectedBooks() {

        String books = "";

        if (cheboxTRIE.isSelected()) {
            books += "The Rain In Espana by 4reuminct - Php 900\n";
        }
        if (cheboxSFTM.isSelected()) {
            books += "Shoot For The Moon by Sheburnnn - Php 720\n";
        }
        if (cheboxBHC.isSelected()) {
            books += "Beyond His Caution by Julliacath - Php 820\n";
        }
        if (cheboxDTB.isSelected()) {
            books += "Drop The Ball by Sheburnnn - Php 720\n";
        }
        if (cheboxWOGO.isSelected()) {
            books += "We're Only Getting Older by Chasmicsol - Php 620\n";
        }
        if (cheboxSSA.isSelected()) {
            books += "Safe Skies, Archer by 4reuminct - Php 900\n";
        }
        if (cheboxCITW.isSelected()) {
            books += "Chasing In The Wind by 4reuminct - Php 900\n";
        }
        if (cheboxAOTD.isSelected()) {
            books += "Aveneus Of The Diamond by 4reuminct - Php 900\n";
        }
        if (cheboxGSOT.isSelected()) {
            books += "Golden Scenery Of Tomorrow by 4reuminct - Php 900\n";
        }
        if (cheboxOYE.isSelected()) {
            books += "Our Yesterday's Escape by 4reuminct - Php 900\n";
        }
        if (cheboxLAGOM.isSelected()) {
            books += "Lay A Glance On Me by Julliacath - Php 820\n";
        }
        if (cheboxCTB.isSelected()) {
            books += "Carry The Ball by Sheburnnn - Php 720\n";
        }
        if (cheboxRAYH.isSelected()) {
            books += "Running After Your Heart by Chasmicsol - Php 620\n";
        }
        if (cheboxTC.isSelected()) {
            books += "Take Charge by Sheburnnn - Php 720\n";
        }
        if (cheboxTWCD.isSelected()) {
            books += "The World Could Die by Chasmicsol - Php 620\n";
        }
        if (cheboxAIAW.isSelected()) {
            books += "Always, In All Ways by Chasmicsol - Php 620\n";
        }
        if (cheboxUTIL.isSelected()) {
            books += "Until There Is Love by Chasmicsol - Php 620\n";
        }
        if (cheboxVS.isSelected()) {
            books += "Volleyball Sweetheart by Smarie027 - Php 400\n";
        }
        if (cheboxCP.isSelected()) {
            books += "Cheerful Pitcher by Smarie027 - Php 400\n";
        }
        if (cheboxSS.isSelected()) {
            books += "Silent Smasher by Smarie027 - Php 400\n";
        }
        if (cheboxBS.isSelected()) {
            books += "Baddass Swimmer by Smarie027 - Php 400\n";
        }
        if (cheboxBG.isSelected()) {
            books += "Basketball Goddess by Smarie027 - Php 400\n";
        }
        if (cheboxAF.isSelected()) {
            books += "Alluring Fighter by Smarie027 - Php 400\n";
        }
        if (cheboxCTS.isSelected()) {
            books += "Chasing The Sun by Inksteady - Php 850\n";
        }
        if (cheboxTTW.isSelected()) {
            books += "Taming The Waves by Inksteady - Php 850\n";
        }
        if (cheboxLC.isSelected()) {
            books += "Love Code by Astraea_02 - Php 510\n";
        }
        if (cheboxCTR.isSelected()) {
            books += "Captured The Remedy by Astraea_02 - Php 510\n";
        }
        if (cheboxUTLS.isSelected()) {
            books += "Until The Last Sunset by Astraea_02 - Php 510\n";
        }
        if (cheboxCY.isSelected()) {
            books += "Chasing You by Astraea_02 - Php 510\n";
        }
        if (cheboxLTS.isSelected()) {
            books += "Loving The Sky by Inksteady - Php 850\n";
        }
        if (cheboxAIK.isSelected()) {
            books += "Alone In Katipunan by Elayynitea - Php 500\n";
        }
        if (cheboxE.isSelected()) {
            books += "Encounter by Elayynitea - Php 500\n";
        }

        return books;
    }

    private String getSelectedCourier() {
        if (rbShop.isSelected()) {
            return "Shoppee - Php 30";
        }
        if (rbJt.isSelected()) {
            return "J&T - Php 20";
        }
        if (rbLbc.isSelected()) {
            return "LBC - Php 200";
        }
        if (rbJres.isSelected()) {
            return "JRS- Php 40";
        }
        if (rbLamove.isSelected()) {
            return "Lalamove - Php 300";
        }
        if (rb2go.isSelected()) {
            return "2GO - Php 50";
        }
        return "";
    }

    private String getSelectedPayment() {
        if (rbGcash.isSelected()) {
            return "GCash";
        }
        if (rbPaymaya.isSelected()) {
            return "PayMaya";
        }
        if (rbMetrobank.isSelected()) {
            return "Metrobank";
        }
        if (rbBdo.isSelected()) {
            return "BDO";
        }
        if (rbCod.isSelected()) {
            return "Cash on Delivery";
        }
        return "";
    }

    private String getPackageOptions() {

        String pack = "";

        if (cheboxBubble.isSelected()) {
            pack += "Bubble Wrap - Php 10\n";
        }

        if (cheboxCarton.isSelected()) {
            pack += "Carton Box - Php 20\n";
        }

        return pack;
    }

    private String getBookType() {

        String type = "";

        if (rbBa.isSelected()) {
            type += "Book Alone - Php 0\n";
        }

        if (rbTlc.isSelected()) {
            type += "TLC Set - Php 600\n";
        }

        return type;
    }

    private double calculateTotal() {

        double total = 0;

        // BOOKS
        if (cheboxTRIE.isSelected()) {
            total += 900;
        }
        if (cheboxSSA.isSelected()) {
            total += 900;
        }
        if (cheboxCITW.isSelected()) {
            total += 900;
        }
        if (cheboxAOTD.isSelected()) {
            total += 900;
        }
        if (cheboxGSOT.isSelected()) {
            total += 900;
        }
        if (cheboxOYE.isSelected()) {
            total += 900;
        }
        if (cheboxSFTM.isSelected()) {
            total += 720;
        }
        if (cheboxCTB.isSelected()) {
            total += 720;
        }
        if (cheboxTC.isSelected()) {
            total += 720;
        }
        if (cheboxBHC.isSelected()) {
            total += 820;
        }
        if (cheboxLAGOM.isSelected()) {
            total += 820;
        }
        if (cheboxCTS.isSelected()) {
            total += 850;
        }
        if (cheboxTTW.isSelected()) {
            total += 850;
        }
        if (cheboxLTS.isSelected()) {
            total += 850;
        }
        if (cheboxDTB.isSelected()) {
            total += 720;
        }
        if (cheboxWOGO.isSelected()) {
            total += 620;
        }
        if (cheboxRAYH.isSelected()) {
            total += 620;
        }
        if (cheboxTWCD.isSelected()) {
            total += 620;
        }
        if (cheboxAIAW.isSelected()) {
            total += 620;
        }
        if (cheboxUTIL.isSelected()) {
            total += 620;
        }
        if (cheboxLC.isSelected()) {
            total += 510;
        }
        if (cheboxCTR.isSelected()) {
            total += 510;
        }
        if (cheboxUTLS.isSelected()) {
            total += 510;
        }
        if (cheboxCY.isSelected()) {
            total += 510;
        }
        if (cheboxVS.isSelected()) {
            total += 400;
        }
        if (cheboxCP.isSelected()) {
            total += 400;
        }
        if (cheboxSS.isSelected()) {
            total += 400;
        }
        if (cheboxBS.isSelected()) {
            total += 400;
        }
        if (cheboxBG.isSelected()) {
            total += 400;
        }
        if (cheboxAF.isSelected()) {
            total += 400;
        }
        if (cheboxAIK.isSelected()) {
            total += 500;
        }
        if (cheboxE.isSelected()) {
            total += 500;
        }

        // PACKAGE
        if (cheboxBubble.isSelected()) {
            total += 10;
        }
        if (cheboxCarton.isSelected()) {
            total += 20;
        }

        // COURIER
        if (rbShop.isSelected()) {
            total += 30;
        }
        if (rbJt.isSelected()) {
            total += 20;
        }
        if (rbLbc.isSelected()) {
            total += 200;
        }
        if (rbJres.isSelected()) {
            total += 40;
        }
        if (rbLamove.isSelected()) {
            total += 300;
        }
        if (rb2go.isSelected()) {
            total += 50;
        }

        // BOOK TYPE
        if (rbTlc.isSelected()) {
            total += 600;
        }

        return total;
    }

    private void updateTotalDisplay() {
        double total = calculateTotal();
        DecimalFormat df = new DecimalFormat("0.00");
        tfTotal.setText("Php " + df.format(total));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblName = new javax.swing.JLabel();
        tfName = new javax.swing.JTextField();
        lblNo = new javax.swing.JLabel();
        tfNo = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        tfEmail = new javax.swing.JTextField();
        lblAdd = new javax.swing.JLabel();
        tfAdd = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        lblPayment = new javax.swing.JLabel();
        rbGcash = new javax.swing.JRadioButton();
        rbPaymaya = new javax.swing.JRadioButton();
        rbBdo = new javax.swing.JRadioButton();
        rbMetrobank = new javax.swing.JRadioButton();
        rbCod = new javax.swing.JRadioButton();
        lblBook = new javax.swing.JLabel();
        cheboxTRIE = new javax.swing.JCheckBox();
        cheboxOYE = new javax.swing.JCheckBox();
        cheboxCITW = new javax.swing.JCheckBox();
        cheboxGSOT = new javax.swing.JCheckBox();
        cheboxAOTD = new javax.swing.JCheckBox();
        cheboxWOGO = new javax.swing.JCheckBox();
        cheboxRAYH = new javax.swing.JCheckBox();
        cheboxTWCD = new javax.swing.JCheckBox();
        cheboxUTIL = new javax.swing.JCheckBox();
        cheboxAIAW = new javax.swing.JCheckBox();
        cheboxAIK = new javax.swing.JCheckBox();
        cheboxCTS = new javax.swing.JCheckBox();
        cheboxTTW = new javax.swing.JCheckBox();
        cheboxLTS = new javax.swing.JCheckBox();
        cheboxBHC = new javax.swing.JCheckBox();
        cheboxLAGOM = new javax.swing.JCheckBox();
        cheboxLC = new javax.swing.JCheckBox();
        cheboxCTR = new javax.swing.JCheckBox();
        cheboxUTLS = new javax.swing.JCheckBox();
        cheboxVS = new javax.swing.JCheckBox();
        cheboxAF = new javax.swing.JCheckBox();
        cheboxSS = new javax.swing.JCheckBox();
        cheboxCP = new javax.swing.JCheckBox();
        cheboxBG = new javax.swing.JCheckBox();
        cheboxTC = new javax.swing.JCheckBox();
        cheboxCTB = new javax.swing.JCheckBox();
        cheboxSFTM = new javax.swing.JCheckBox();
        cheboxDTB = new javax.swing.JCheckBox();
        cheboxCY = new javax.swing.JCheckBox();
        cheboxSSA = new javax.swing.JCheckBox();
        cheboxE = new javax.swing.JCheckBox();
        cheboxBS = new javax.swing.JCheckBox();
        lblBatlc = new javax.swing.JLabel();
        rbBa = new javax.swing.JRadioButton();
        rbTlc = new javax.swing.JRadioButton();
        lblDeliver = new javax.swing.JLabel();
        rbShop = new javax.swing.JRadioButton();
        rbLamove = new javax.swing.JRadioButton();
        rbJres = new javax.swing.JRadioButton();
        lblPack = new javax.swing.JLabel();
        cheboxBubble = new javax.swing.JCheckBox();
        cheboxCarton = new javax.swing.JCheckBox();
        rb2go = new javax.swing.JRadioButton();
        rbJt = new javax.swing.JRadioButton();
        rbLbc = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        lblTotal = new javax.swing.JLabel();
        tfTotal = new javax.swing.JTextField();
        btnSubmit = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 204, 255));

        lblName.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblName.setText("NAME");

        tfName.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tfName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfNameKeyPressed(evt);
            }
        });

        lblNo.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblNo.setText("CONTACT NO");

        tfNo.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tfNo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfNoKeyPressed(evt);
            }
        });

        lblEmail.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblEmail.setText("EMAIL ADDRESS");

        tfEmail.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        lblAdd.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblAdd.setText("PERMANENT ADDRESS");

        tfAdd.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblAdd)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfAdd))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblName)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfName, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblNo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfNo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblEmail)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(102, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblName)
                    .addComponent(tfName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNo)
                    .addComponent(tfNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEmail)
                    .addComponent(tfEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAdd)
                    .addComponent(tfAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.PAGE_START);

        jPanel2.setBackground(new java.awt.Color(102, 204, 255));

        lblPayment.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblPayment.setText("MODE OF PAYMENT");

        rbGcash.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rbGcash.setText("GCASH");
        rbGcash.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbGcashItemStateChanged(evt);
            }
        });

        rbPaymaya.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rbPaymaya.setText("PAYMAYA");
        rbPaymaya.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbGcashItemStateChanged(evt);
            }
        });

        rbBdo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rbBdo.setText("BDO");
        rbBdo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbGcashItemStateChanged(evt);
            }
        });

        rbMetrobank.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rbMetrobank.setText("METROBANK");
        rbMetrobank.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbGcashItemStateChanged(evt);
            }
        });

        rbCod.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rbCod.setText("COD");
        rbCod.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbGcashItemStateChanged(evt);
            }
        });

        lblBook.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblBook.setText("WHAT'S BOOK DO YOU WANT TO BUY?");

        cheboxTRIE.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxTRIE.setText("THE RAIN IN ESPANA by 4REUMINCT");
        cheboxTRIE.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxOYE.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxOYE.setText("OUR YESTERDAY'S ESCAPE by 4REUMINCT");
        cheboxOYE.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxCITW.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxCITW.setText("CHASING IN THE WILD by 4REUMINCT");
        cheboxCITW.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxGSOT.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxGSOT.setText("GOLDEN SCENERY OF TOMORROW by 4REUMINCT");
        cheboxGSOT.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxAOTD.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxAOTD.setText("AVENUES OF THE DIAMOND by 4REUMINCT");
        cheboxAOTD.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxWOGO.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxWOGO.setText("WE'RE ONLY GETTING OLDER by CHASMICSOL");
        cheboxWOGO.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxRAYH.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxRAYH.setText("RUNNING AFTER YOUR HEART by CHASMICSOL");
        cheboxRAYH.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxTWCD.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxTWCD.setText("THE WORLD COULD DIE by CHASMICSOL");
        cheboxTWCD.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxUTIL.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxUTIL.setText("UNTIL THERE IS LOVE by CHASMICSOL");
        cheboxUTIL.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxAIAW.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxAIAW.setText("ALWAYS, IN ALL WAYS by CHASMICSOL");
        cheboxAIAW.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxAIK.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxAIK.setText("ALONE IN KATIPUNAN by ELAYYNITEA");
        cheboxAIK.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxCTS.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxCTS.setText("CHASING THE SUN by INKSTEADY");
        cheboxCTS.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxTTW.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxTTW.setText("TAMING THE WAVES by INKSTEADY");
        cheboxTTW.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxLTS.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxLTS.setText("LOVING THE SKY by INKSTEADY");
        cheboxLTS.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxBHC.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxBHC.setText("BEYOND HIS CAUTION by JULLIACATH");
        cheboxBHC.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxLAGOM.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxLAGOM.setText("LAY A GLANCE ON ME by JULLIACATH");
        cheboxLAGOM.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxLC.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxLC.setText("LOVE CODE by ASTRAEA_02");
        cheboxLC.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxCTR.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxCTR.setText("CAPTURED THE REMEDY by ASTRAEA_02");
        cheboxCTR.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxUTLS.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxUTLS.setText("UNTIL THE LAST SUNSET by ASTRAEA_02");
        cheboxUTLS.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxVS.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxVS.setText("VOLLEYBALL SWEETHEART by SMARIE027");
        cheboxVS.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxAF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxAF.setText("ALLURING FIGHTER by SMARIE027");
        cheboxAF.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxSS.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxSS.setText("SILENT SMASHER by SMARIE027");
        cheboxSS.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxCP.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxCP.setText("CHEERFUL PITCHER by SMARIE027");
        cheboxCP.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxBG.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxBG.setText("BASKETBALL GODDESS by SMARIE027");
        cheboxBG.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxTC.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxTC.setText("TAKE CHARGE by SHEBURNNN");
        cheboxTC.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxCTB.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxCTB.setText("CARRY THE BALL by SHEBURNNN");
        cheboxCTB.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxSFTM.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxSFTM.setText("SHOOT FOR THE MOON by SHEBURNNN");
        cheboxSFTM.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxDTB.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxDTB.setText("DROP THE BALL by SHEBURNNN");
        cheboxDTB.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxCY.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxCY.setText("CHASING YOU by ASTRAEA_02");
        cheboxCY.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxSSA.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxSSA.setText("SAFE SKIES, ARCHER by 4REUMINCT");
        cheboxSSA.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxE.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxE.setText("ENCOUNTER by ELAYYNITEA");
        cheboxE.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        cheboxBS.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxBS.setText("BADASS SWIMMER by SMARIE027");
        cheboxBS.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxTRIEItemStateChanged(evt);
            }
        });

        lblBatlc.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblBatlc.setText("BOOK ALONE OR TLC?");

        rbBa.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        rbBa.setText("BOOK ALONE (WITH FREEBIES, BOOKMARK AND POSTER)");
        rbBa.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbBaItemStateChanged(evt);
            }
        });

        rbTlc.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        rbTlc.setText("TLC (WITH FREEBIES, BOOKMARK, POSTER, NECKLACE, STICKER, ETC.)");
        rbTlc.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbTlcItemStateChanged(evt);
            }
        });

        lblDeliver.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblDeliver.setText("MODE OF DELIVERY");

        rbShop.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        rbShop.setText("SHOPPEE");
        rbShop.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbShopItemStateChanged(evt);
            }
        });

        rbLamove.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        rbLamove.setText("LALAMOVE");
        rbLamove.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbShopItemStateChanged(evt);
            }
        });

        rbJres.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        rbJres.setText("JRES EXPRESS");
        rbJres.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbShopItemStateChanged(evt);
            }
        });

        lblPack.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblPack.setText("PACKAGE OPTIONS");

        cheboxBubble.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxBubble.setText("BUBBLE WRAP");
        cheboxBubble.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxBubbleItemStateChanged(evt);
            }
        });

        cheboxCarton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cheboxCarton.setText("CARTON BOX");
        cheboxCarton.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cheboxBubbleItemStateChanged(evt);
            }
        });

        rb2go.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        rb2go.setText("2GO EXPRESS");
        rb2go.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbShopItemStateChanged(evt);
            }
        });

        rbJt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        rbJt.setText("J&T EXPRESS");
        rbJt.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbShopItemStateChanged(evt);
            }
        });

        rbLbc.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        rbLbc.setText("LBC");
        rbLbc.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbShopItemStateChanged(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(102, 204, 255));

        lblTotal.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblTotal.setText("TOTAL AMOUNT");

        tfTotal.setEditable(false);
        tfTotal.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        btnSubmit.setText("SUBMIT");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });

        btnClear.setText("CLEAR");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(357, 357, 357)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(btnSubmit)
                        .addGap(30, 30, 30)
                        .addComponent(btnClear))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblTotal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(474, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTotal)
                    .addComponent(tfTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSubmit)
                    .addComponent(btnClear))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblBook)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cheboxAIK)
                                    .addComponent(cheboxCTS)
                                    .addComponent(cheboxTTW)
                                    .addComponent(cheboxLTS)
                                    .addComponent(cheboxLC)
                                    .addComponent(cheboxCTR)
                                    .addComponent(cheboxUTLS)
                                    .addComponent(cheboxE)
                                    .addComponent(cheboxBHC)
                                    .addComponent(cheboxLAGOM))))
                        .addGap(90, 90, 90)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cheboxCITW)
                                    .addComponent(cheboxGSOT)
                                    .addComponent(cheboxTRIE)
                                    .addComponent(cheboxOYE)
                                    .addComponent(cheboxSSA)
                                    .addComponent(cheboxAOTD))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(cheboxWOGO)
                                    .addGap(20, 20, 20)))
                            .addComponent(cheboxTWCD)
                            .addComponent(cheboxUTIL)
                            .addComponent(cheboxAIAW)
                            .addComponent(cheboxRAYH))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cheboxTC)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cheboxVS)
                                    .addComponent(cheboxDTB)
                                    .addComponent(cheboxCY))
                                .addComponent(cheboxAF)
                                .addComponent(cheboxBS)
                                .addComponent(cheboxSS)
                                .addComponent(cheboxCP)
                                .addComponent(cheboxBG))
                            .addComponent(cheboxCTB)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblPayment)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(rbPaymaya)
                                            .addComponent(rbGcash)
                                            .addComponent(rbBdo)
                                            .addComponent(rbMetrobank)
                                            .addComponent(rbCod))))
                                .addComponent(cheboxSFTM)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblBatlc)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(rbTlc)
                                            .addComponent(rbBa))))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(21, 21, 21)
                                        .addComponent(lblPack))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(31, 31, 31)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(cheboxCarton)
                                            .addComponent(cheboxBubble)))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(637, 637, 637)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblDeliver)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(rbLamove)
                                            .addComponent(rbShop)
                                            .addComponent(rbJres)
                                            .addComponent(rb2go)
                                            .addComponent(rbJt)
                                            .addComponent(rbLbc))))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lblBook)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxAIK)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxCTS)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxTTW)
                        .addGap(1, 1, 1)
                        .addComponent(cheboxLTS)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxBHC)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxLAGOM)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxLC)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxCTR)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxUTLS))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(cheboxTRIE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxSSA)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxOYE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxCITW)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxGSOT)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(cheboxWOGO))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cheboxAOTD)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxRAYH)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxTWCD)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxUTIL)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxAIAW))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(cheboxVS)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxBS)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxAF)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxSS)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxCP)
                        .addGap(1, 1, 1)
                        .addComponent(cheboxBG)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxTC)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxCTB)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxSFTM)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxDTB)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxCY)))
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lblPack)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxBubble)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cheboxCarton))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lblBatlc)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbBa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbTlc))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(lblDeliver)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbShop)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbLamove)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbJres)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rb2go)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbJt))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(lblPayment)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbGcash)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbPaymaya)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbBdo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbMetrobank)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbCod)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbLbc)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(jPanel2, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfNoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfNoKeyPressed
        int value = evt.getKeyChar();

        if (value >= KeyEvent.VK_0 && value <= KeyEvent.VK_9 || value == KeyEvent.VK_BACK_SPACE)
            tfNo.setEditable(true);
        else if (value == KeyEvent.VK_ENTER) {
            int num = Integer.parseInt(tfNo.getText());
            tfNo.setText(Integer.toString(num * num));
        } else {
            tfNo.setEditable(false);
            JOptionPane.showMessageDialog(this, "Please, enter numbers 0-9 only!");
        }
    }//GEN-LAST:event_tfNoKeyPressed

    private void cheboxBubbleItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cheboxBubbleItemStateChanged
        if (evt.getStateChange() == ItemEvent.SELECTED) {
            bubble = true;
            carton = true;
            updateTotalDisplay();
        } else {
            bubble = false;
            carton = false;
        }
    }//GEN-LAST:event_cheboxBubbleItemStateChanged

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        try {

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO orders (name, email, phone, address, books, courier, payment, total) VALUES (?,?,?,?,?,?,?,?)";
            double total = calculateTotal();
            DecimalFormat df = new DecimalFormat("0.00");
            tfTotal.setText("Php " + df.format(total));

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, tfName.getText());
            pst.setString(2, tfEmail.getText());
            pst.setString(3, tfNo.getText());
            pst.setString(4, tfAdd.getText());
            pst.setString(5, getSelectedBooks());
            pst.setString(6, getSelectedCourier());
            pst.setString(7, getSelectedPayment());
            pst.setDouble(8, total);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "Your Order is Success!");

            // ================= RECEIPT =================
            String receipt = "";

            receipt += "========== MORENAJOY'S BOOKSTORE ==========\n\n";

            receipt += "Customer Name: " + tfName.getText() + "\n";
            receipt += "Email: " + tfEmail.getText() + "\n";
            receipt += "Phone Number: " + tfNo.getText() + "\n";
            receipt += "Address: " + tfAdd.getText() + "\n\n";

            receipt += "Book/s:\n" + getSelectedBooks() + "\n";
            receipt += "Book Type:\n" + getBookType() + "\n";
            receipt += "Package:\n" + getPackageOptions() + "\n";
            receipt += "Courier:\n" + getSelectedCourier() + "\n\n";
            receipt += "Payment Method: " + getSelectedPayment() + "\n\n";

            receipt += "Total Amount: Php " + df.format(total) + "\n\n";

            receipt += "Thank you for your order!";

            ReceiptFrame rf = new ReceiptFrame();

            rf.setReceipt(receipt);
            rf.setVisible(true);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        tfName.setText(null);
        tfNo.setText(null);
        tfEmail.setText(null);
        tfAdd.setText(null);

        rbGcash.setSelected(false);
        rbPaymaya.setSelected(false);
        rbMetrobank.setSelected(false);
        rbBdo.setSelected(false);
        rbCod.setSelected(false);

        cheboxTRIE.setSelected(false);
        cheboxVS.setSelected(false);
        cheboxE.setSelected(false);
        cheboxSSA.setSelected(false);
        cheboxBS.setSelected(false);
        cheboxAIK.setSelected(false);
        cheboxOYE.setSelected(false);
        cheboxAF.setSelected(false);
        cheboxCTS.setSelected(false);
        cheboxCITW.setSelected(false);
        cheboxSS.setSelected(false);
        cheboxTTW.setSelected(false);
        cheboxGSOT.setSelected(false);
        cheboxCP.setSelected(false);
        cheboxLTS.setSelected(false);
        cheboxAOTD.setSelected(false);
        cheboxBG.setSelected(false);
        cheboxBHC.setSelected(false);
        cheboxWOGO.setSelected(false);
        cheboxTC.setSelected(false);
        cheboxLAGOM.setSelected(false);
        cheboxRAYH.setSelected(false);
        cheboxCTB.setSelected(false);
        cheboxLC.setSelected(false);
        cheboxTWCD.setSelected(false);
        cheboxSFTM.setSelected(false);
        cheboxCTR.setSelected(false);
        cheboxUTIL.setSelected(false);
        cheboxDTB.setSelected(false);
        cheboxUTLS.setSelected(false);
        cheboxAIAW.setSelected(false);
        cheboxCY.setSelected(false);

        rbBa.setSelected(false);
        rbTlc.setSelected(false);

        rbShop.setSelected(false);
        rbLamove.setSelected(false);
        rbJt.setSelected(false);
        rbJres.setSelected(false);
        rb2go.setSelected(false);
        rbLbc.setSelected(false);

        cheboxBubble.setSelected(false);
        cheboxCarton.setSelected(false);

        tfTotal.setText(null);
    }//GEN-LAST:event_btnClearActionPerformed

    private void cheboxTRIEItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cheboxTRIEItemStateChanged
        if (evt.getSource() == cheboxTRIE) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxSFTM) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxBHC) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxDTB) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxWOGO) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxSSA) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            }
        }

        if (evt.getSource() == cheboxCITW) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxAOTD) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxGSOT) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxOYE) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxLAGOM) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxCTB) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxRAYH) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxTC) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxTWCD) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxAIAW) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxUTIL) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxVS) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxCP) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxSS) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxBS) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxBG) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxAF) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxCTS) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxTTW) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxLC) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxCTR) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxUTLS) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxCY) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxLTS) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxAIK) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }

        if (evt.getSource() == cheboxE) {
            if (evt.getStateChange() == 1) {
                book = true;
                updateTotalDisplay();
            } else {
                book = false;
            }
        }
    }//GEN-LAST:event_cheboxTRIEItemStateChanged

    private void rbBaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rbBaItemStateChanged
        if (evt.getSource() == rbBa) {
            if (evt.getStateChange() == 1) {
                updateTotalDisplay();
            }
        }
    }//GEN-LAST:event_rbBaItemStateChanged

    private void rbShopItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rbShopItemStateChanged
        if (evt.getSource() == rbShop) {
            if (evt.getStateChange() == 1) {
                updateTotalDisplay();
            }
        }

        if (evt.getSource() == rbJt) {
            if (evt.getStateChange() == 1) {
                updateTotalDisplay();
            }
        }

        if (evt.getSource() == rbLbc) {
            if (evt.getStateChange() == 1) {
                updateTotalDisplay();
            }
        }

        if (evt.getSource() == rbJres) {
            if (evt.getStateChange() == 1) {
                updateTotalDisplay();
            }
        }

        if (evt.getSource() == rbLamove) {
            if (evt.getStateChange() == 1) {
                updateTotalDisplay();
            }
        }

        if (evt.getSource() == rb2go) {
            if (evt.getStateChange() == 1) {
                updateTotalDisplay();
            }
        }
    }//GEN-LAST:event_rbShopItemStateChanged

    private void rbGcashItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rbGcashItemStateChanged

        if (evt.getSource() == rbCod) {
            if (evt.getStateChange() == 1) {
                updateTotalDisplay();
            }
        }

    }//GEN-LAST:event_rbGcashItemStateChanged

    private void rbTlcItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rbTlcItemStateChanged
        if (evt.getSource() == rbTlc) {
            if (evt.getStateChange() == 1) {
                updateTotalDisplay();
            }
        }
    }//GEN-LAST:event_rbTlcItemStateChanged

    private void tfNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfNameKeyPressed
        char name = evt.getKeyChar();

        if (Character.isLetter(name) || Character.isWhitespace(name) || Character.isISOControl(name)) {
            tfName.setEditable(true);
        } else {
            tfName.setEditable(false);
            JOptionPane.showMessageDialog(this, "Please, enter your name!");
        }
    }//GEN-LAST:event_tfNameKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OrderFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OrderFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OrderFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OrderFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OrderFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JCheckBox cheboxAF;
    private javax.swing.JCheckBox cheboxAIAW;
    private javax.swing.JCheckBox cheboxAIK;
    private javax.swing.JCheckBox cheboxAOTD;
    private javax.swing.JCheckBox cheboxBG;
    private javax.swing.JCheckBox cheboxBHC;
    private javax.swing.JCheckBox cheboxBS;
    private javax.swing.JCheckBox cheboxBubble;
    private javax.swing.JCheckBox cheboxCITW;
    private javax.swing.JCheckBox cheboxCP;
    private javax.swing.JCheckBox cheboxCTB;
    private javax.swing.JCheckBox cheboxCTR;
    private javax.swing.JCheckBox cheboxCTS;
    private javax.swing.JCheckBox cheboxCY;
    private javax.swing.JCheckBox cheboxCarton;
    private javax.swing.JCheckBox cheboxDTB;
    private javax.swing.JCheckBox cheboxE;
    private javax.swing.JCheckBox cheboxGSOT;
    private javax.swing.JCheckBox cheboxLAGOM;
    private javax.swing.JCheckBox cheboxLC;
    private javax.swing.JCheckBox cheboxLTS;
    private javax.swing.JCheckBox cheboxOYE;
    private javax.swing.JCheckBox cheboxRAYH;
    private javax.swing.JCheckBox cheboxSFTM;
    private javax.swing.JCheckBox cheboxSS;
    private javax.swing.JCheckBox cheboxSSA;
    private javax.swing.JCheckBox cheboxTC;
    private javax.swing.JCheckBox cheboxTRIE;
    private javax.swing.JCheckBox cheboxTTW;
    private javax.swing.JCheckBox cheboxTWCD;
    private javax.swing.JCheckBox cheboxUTIL;
    private javax.swing.JCheckBox cheboxUTLS;
    private javax.swing.JCheckBox cheboxVS;
    private javax.swing.JCheckBox cheboxWOGO;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblAdd;
    private javax.swing.JLabel lblBatlc;
    private javax.swing.JLabel lblBook;
    private javax.swing.JLabel lblDeliver;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblNo;
    private javax.swing.JLabel lblPack;
    private javax.swing.JLabel lblPayment;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JRadioButton rb2go;
    private javax.swing.JRadioButton rbBa;
    private javax.swing.JRadioButton rbBdo;
    private javax.swing.JRadioButton rbCod;
    private javax.swing.JRadioButton rbGcash;
    private javax.swing.JRadioButton rbJres;
    private javax.swing.JRadioButton rbJt;
    private javax.swing.JRadioButton rbLamove;
    private javax.swing.JRadioButton rbLbc;
    private javax.swing.JRadioButton rbMetrobank;
    private javax.swing.JRadioButton rbPaymaya;
    private javax.swing.JRadioButton rbShop;
    private javax.swing.JRadioButton rbTlc;
    private javax.swing.JTextField tfAdd;
    private javax.swing.JTextField tfEmail;
    private javax.swing.JTextField tfName;
    private javax.swing.JTextField tfNo;
    private javax.swing.JTextField tfTotal;
    // End of variables declaration//GEN-END:variables

    private void setIconImage() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
        setTitle("MorenaJoy's BookStore");
    }
}
